current_price = int(input())
last_months_price = int(input())
change_price = current_price - last_months_price
monthly_mortgage = (current_price * 0.051) / 12

print(f'This house is ${current_price}. The change is ${change_price} since last month.')
print(f'The estimated monthly mortgage is ${monthly_mortgage:.2f}.')
