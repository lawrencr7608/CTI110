def laps_to_miles(user_miles):
    laps_to_miles = user_miles / 4
    return laps_to_miles

if __name__ == '__main__': 
    user_miles = float(input())
    print(f'{laps_to_miles(user_miles):.2f}')